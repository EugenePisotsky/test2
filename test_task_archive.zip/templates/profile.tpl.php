<div id="main">
    Имя: <?=$profile['first_name'] . ' ' . $profile['last_name'] ?><br />
    E-mail: <?=$profile['email'] ?><br />
    <a href="/?page=logout">Выйти из сайта</a>
</div>