<?php
$i18n = [
    'test_message' => 'Test Message',
    'pageNotFoundTitle' => 'Page not found!',
    'homePageTitle' => 'Home Page',

    /*
     * Registration page
     */

    'Description' => 'Welcome to the test page.'
];