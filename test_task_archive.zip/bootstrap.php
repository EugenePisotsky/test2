<?php
session_start();

require 'config.php';
require ROOT . '/models/AppModel.php';
require 'models.php';
require 'i18n.php';
require 'validator.php';
require 'view.php';